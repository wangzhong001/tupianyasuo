package com.xinqidian.adcommon.app;

/**
 * Created by lipei on 2018/12/17.
 */

public interface LiveBusConfig {
    String login="login";

    String alipaySuccess="alipaySuccess";

    String userData="userData";

    String title="title";






















}
