package com.xinqidian.adcommon.login;

import android.app.Activity;
import android.app.Dialog;

import com.trello.rxlifecycle2.LifecycleTransformer;
import com.xinqidian.adcommon.app.AppConfig;
import com.xinqidian.adcommon.app.BaseServiceApi;
import com.xinqidian.adcommon.app.LiveBusConfig;
import com.xinqidian.adcommon.bus.LiveDataBus;
import com.xinqidian.adcommon.http.BaseResponse;
import com.xinqidian.adcommon.http.net.NetWorkSubscriber;
import com.xinqidian.adcommon.http.util.RetrofitClient;
import com.xinqidian.adcommon.http.util.RxUtils;
import com.xinqidian.adcommon.util.AesUtil;
import com.xinqidian.adcommon.util.PayUtils;
import com.xinqidian.adcommon.util.SharedPreferencesUtil;
import com.xinqidian.adcommon.util.ToastUtils;

/**
 * Created by lipei on 2020/6/6.
 */

public class UserUtil {

    /**
     * 登录
     *
     * @param account
     * @param password
     */
    public static void login(final String account, final String password, final CallBack callBack, final Dialog dialog) {

        LoginRequestBody loginRequestBody = new LoginRequestBody();
        loginRequestBody.setLoginName(account);
        loginRequestBody.setPassword(AesUtil.aesEncrypt(password, AesUtil.KEY));
        RetrofitClient.getInstance().create(BaseServiceApi.class)
                .login(loginRequestBody)
                .compose(RxUtils.schedulersTransformer())
                .subscribeWith(new NetWorkSubscriber<BaseResponse>() {
                    @Override
                    protected Dialog showDialog() {
                        return dialog;
                    }

                    @Override
                    protected void onSuccess(BaseResponse o) {
                        if (o.getCode() == AppConfig.user_not_regist) {
                            //用户未注册
                            regist(account, password, new NetWorkSubscriber<BaseResponse>() {
                                @Override
                                protected Dialog showDialog() {
                                    return dialog;
                                }

                                @Override
                                protected void onSuccess(BaseResponse o) {
                                    if (o.getCode() == AppConfig.success_code) {
                                        SharedPreferencesUtil.toLogin();
                                        getUserInfo();
                                        if (callBack != null) {
                                            callBack.onSuccess();
                                        }

                                    } else {
                                        ToastUtils.show(o.getMsg());
                                        if (callBack != null) {
                                            callBack.onFail();
                                        }

                                    }

                                }
                            });

                        } else if (o.getCode() == AppConfig.success_code) {
                            SharedPreferencesUtil.toLogin();
                            getUserInfo();
                            if (callBack != null) {
                                callBack.onSuccess();
                            }

                        } else {
                            ToastUtils.show(o.getMsg());
                            if (callBack != null) {
                                callBack.onFail();
                            }

                        }

                    }
                });


    }


    /**
     * 退出登录
     */
    public static void exitLogin(){
        RetrofitClient.getInstance().create(BaseServiceApi.class)
                .exitLogin()
                .compose(RxUtils.schedulersTransformer())
                .subscribe(new NetWorkSubscriber<BaseResponse>() {
                    @Override
                    protected Dialog showDialog() {
                        return null;
                    }

                    @Override
                    protected void onSuccess(BaseResponse baseResponse) {
                        if(baseResponse.getCode()==AppConfig.success_code){
                            SharedPreferencesUtil.exitLogin();
                        }else {
                            ToastUtils.show(baseResponse.getMsg());
                        }

                    }
                });
    }


    /**
     * 获取用户信息
     */
    public static void getUserInfo(){
        RetrofitClient.getInstance().create(BaseServiceApi.class)
                .getUserInfo()
                .compose(RxUtils.schedulersTransformer())
                .subscribe(new NetWorkSubscriber<UserModel>() {
                    @Override
                    protected Dialog showDialog() {
                        return null;
                    }

                    @Override
                    protected void onSuccess(UserModel userModel) {
                        if(userModel.getCode()==AppConfig.success_code){
                            if(userModel.getData()!=null){
                                String expireDate=userModel.getData().getExpireDate();
                                if(expireDate!=null){
                                    //是会员
                                    SharedPreferencesUtil.setVip(true);
                                }else {
                                    //不是会员
                                    SharedPreferencesUtil.setVip(false);

                                }

                                LiveDataBus.get().with(LiveBusConfig.userData,UserModel.DataBean.class).postValue(userModel.getData());

                            }

                        }else if(userModel.getCode()==AppConfig.login_fail){
                            SharedPreferencesUtil.exitLogin();
                        }

                    }
                });
    }



    public interface UserinfoCallBack{
        void getUserInfo(UserModel.DataBean dataBean);
    }


    /**
     * 获取用户信息
     */
    public static void getUserInfoCallBack(final UserinfoCallBack userinfoCallBack){
        RetrofitClient.getInstance().create(BaseServiceApi.class)
                .getUserInfo()
                .compose(RxUtils.schedulersTransformer())
                .subscribe(new NetWorkSubscriber<UserModel>() {
                    @Override
                    protected Dialog showDialog() {
                        return null;
                    }

                    @Override
                    protected void onSuccess(UserModel userModel) {
                        if(userModel.getCode()==AppConfig.success_code){
                            if(userModel.getData()!=null){
                                String phoneNumber=userModel.getData().getMobile();
                                String expireDate=userModel.getData().getExpireDate();


                                if(expireDate!=null){
                                    //是会员
                                    SharedPreferencesUtil.setVip(true);
                                }else {
                                    //不是会员
                                    SharedPreferencesUtil.setVip(false);

                                }

                                if(userinfoCallBack!=null){
                                    userinfoCallBack.getUserInfo(userModel.getData());
                                }
                            }

                        }else if(userModel.getCode()==AppConfig.login_fail){
                            SharedPreferencesUtil.exitLogin();
                        }

                    }
                });
    }



    /**
     *
     * @param mercdName 会员订阅名称 一个月会员、三个月会员、一年会员
     * @param mercdWorth 订阅金额
     * @param orderNumber 订阅类型  1:一个月  3:3个月   12 一年
     * @param activity
     * @param callBack
     */

    public static void alipayOrder(String mercdName, String mercdWorth, int orderNumber, final Activity activity, final CallBack callBack) {
        AllipayRequestBody allipayRequestBody = new AllipayRequestBody();
        allipayRequestBody.setMercdName(mercdName);
        allipayRequestBody.setMercdWorth(mercdWorth);
        allipayRequestBody.setOrderNumber(orderNumber);
        RetrofitClient.getInstance().create(BaseServiceApi.class)
                .alipayCreateOrdr(allipayRequestBody)
                .compose(RxUtils.schedulersTransformer())
                .subscribe(new NetWorkSubscriber<AlipayModel>() {
                    @Override
                    protected Dialog showDialog() {
                        return null;
                    }

                    @Override
                    protected void onSuccess(AlipayModel alipayModel) {
                        if (alipayModel.getCode() == AppConfig.success_code) {
                            if (alipayModel.getData() != null) {
                                String orderString = alipayModel.getData().getOrderStr();
                                PayUtils.pay(PayUtils.PAY_TYPE_ALI, orderString, activity);
                            } else {
                                ToastUtils.show("支付失败");

                            }

                        } else if (alipayModel.getCode()==AppConfig.login_fail) {

                            if(callBack!=null){
                                callBack.loginFial();
                            }
                            SharedPreferencesUtil.exitLoginNotSend();

                            //登录失败

                        } else {
                            ToastUtils.show(alipayModel.getMsg());
                        }

                    }
                });
    }


    /**
     * 注册
     *
     * @param account
     * @param password
     * @param observable
     */
    public static void regist(String account, String password, NetWorkSubscriber observable) {

        RegistRequestBody registRequestBody = new RegistRequestBody();
        registRequestBody.setAccount(account);
        registRequestBody.setPassword(AesUtil.aesEncrypt(password, AesUtil.KEY));
        registRequestBody.setRePassword(AesUtil.aesEncrypt(password, AesUtil.KEY));


        RetrofitClient.getInstance().create(BaseServiceApi.class)
                .regist(registRequestBody)
                .compose(RxUtils.schedulersTransformer())
                .subscribeWith(observable);


    }





    /**
     * 支付宝成功回调
     * @param observable
     */
    public static void alipaySuccess(NetWorkSubscriber observable) {




        RetrofitClient.getInstance().create(BaseServiceApi.class)
                .alipaySuceessCallBack()
                .compose(RxUtils.schedulersTransformer())
                .subscribeWith(observable);


    }



    public interface CallBack {
        void onSuccess();

        void onFail();

        void loginFial();
    }


}
