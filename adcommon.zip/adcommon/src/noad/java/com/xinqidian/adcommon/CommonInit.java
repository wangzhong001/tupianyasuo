package com.xinqidian.adcommon;

import android.app.Application;


/**
 * Created by lipei on 2020/4/27.
 */

public class CommonInit {
    private static final String TAG = "XiaomiCommon";

    public static void init(Application application) {

    }

}
