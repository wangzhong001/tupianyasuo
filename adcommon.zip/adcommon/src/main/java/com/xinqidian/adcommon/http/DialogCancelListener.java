package com.xinqidian.adcommon.http;

/**
 * Created by lipei on 2018/1/29.
 */

public interface DialogCancelListener {
    /**
     * 取消网络请求
     */
    void onCancel();
}
