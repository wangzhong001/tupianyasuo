package com.xinqidian.adcommon.app;

/**
 * Created by lipei on 2019/1/9.
 */

public interface BaseUrlApi {
    /**
     * 登录
     */
    String login="/api/user/login/login.json";



    /**
     * 退出登录
     */
    String exitLogin="/api/user/login/loginOut.json";




    /**
     * 注册
     */
    String regist="/api/user/register/account.json";



    /**
     *支付宝创建订单
     */
    String alipayCreateOrdr="/api/payOrder/createAliOrder.json";




    /**
     *支付宝支付成功回调
     */
    String alipaySuccessCall="/api/alipay/payMessCallBack.json";



    /**
     *获取用户信息
     */
    String getUserInfo="/api/user/info/home.json";





//    /**
//     * 获取最新版本
//     */
//    String new_version="/underwriter/getVersion.json";




}
