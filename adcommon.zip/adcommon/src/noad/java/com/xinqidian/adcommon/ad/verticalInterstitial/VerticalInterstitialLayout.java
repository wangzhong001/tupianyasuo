package com.xinqidian.adcommon.ad.verticalInterstitial;
import android.content.Context;
import com.xinqidian.adcommon.ad.banner.BannerInterface;

/**
 * Created by lipei on 2020/5/9.
 */

public class VerticalInterstitialLayout {
    private BannerInterface bannerInterface;

    public VerticalInterstitialLayout(Context context, BannerInterface bannerInterface) {
        this.bannerInterface = bannerInterface;


    }

    public void loadAd() {


    }

    public void showAd() {

    }


}
