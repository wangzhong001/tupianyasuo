package com.xinqidian.adcommon.view;

/**
 * Created by lipei on 2020/5/31.
 */

public interface SecretInterface {
    void canelClick();

    void sureClick();

    void xieyiClick();

    void yinsiClick();
}
