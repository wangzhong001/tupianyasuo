package com.xinqidian.adcommon.app;


import com.xinqidian.adcommon.http.BaseResponse;
import com.xinqidian.adcommon.login.AlipayModel;
import com.xinqidian.adcommon.login.AllipayRequestBody;
import com.xinqidian.adcommon.login.LoginRequestBody;
import com.xinqidian.adcommon.login.RegistRequestBody;
import com.xinqidian.adcommon.login.UserModel;

import io.reactivex.Observable;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;
import retrofit2.http.Query;

/**
 * Created by lipei on 2019/1/9.
 */

public interface BaseServiceApi {

    /**
     * 登录
     * @param loginRequestBody
     * @return
     */
    @POST(BaseUrlApi.login)
    Observable<BaseResponse> login(@Body LoginRequestBody loginRequestBody);





    /**
     * 退出登录
     * @return
     */
    @GET(BaseUrlApi.exitLogin)
    Observable<BaseResponse> exitLogin();





    /**
     * 注册
     * @param loginRequestBody
     * @return
     */
    @POST(BaseUrlApi.regist)
    Observable<BaseResponse> regist(@Body RegistRequestBody loginRequestBody);





    /**
     * 支付宝创建订单
     * @param allipayRequestBody
     * @return
     */
    @POST(BaseUrlApi.alipayCreateOrdr)
    Observable<AlipayModel> alipayCreateOrdr(@Body AllipayRequestBody allipayRequestBody);





    /**
     * 支付宝支付成功回调
     * @return
     */
    @POST(BaseUrlApi.alipaySuccessCall)
    Observable<BaseResponse> alipaySuceessCallBack();




    /**
     * 获取用户信息
     * @return
     */
    @GET(BaseUrlApi.getUserInfo)
    Observable<UserModel> getUserInfo();


//    /**
//     * 获取最新版本
//     *
//     */
//
//    @GET(BaseUrlApi.new_version)
//    Observable<UpdateBean> getNewVersion(@Query("platform") String desc, @Header("Accept-Language") String lang);





}
