package com.xinqidian.adcommon.http.net;

/**
 * Created by lipei on 2018/11/28.
 */

public class NetWorkRequest {
//    public <T>void netWork(Observable<T> observable, LifecycleProvider lifecycleProvider){
//        observable
//                .compose(RxUtils.bindToLifecycle(lifecycleProvider)) //请求与View周期同步
//                .compose(RxUtils.schedulersTransformer()) //线程调度
//                .compose(RxUtils.exceptionTransformer()) // 网络错误的异常转换, 这里可以换成自己的ExceptionHandle
//    }

}
