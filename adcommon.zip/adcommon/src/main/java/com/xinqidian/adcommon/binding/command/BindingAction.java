package com.xinqidian.adcommon.binding.command;

/**
 * A zero-argument action.
 */

public interface BindingAction {
    void call();
}
